export const LinkWord = {
  textDecoration: "none",
  color: "#B22727"
}