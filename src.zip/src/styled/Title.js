import styled from "styled-components"

export const Title = styled.h1`
  text-align: center;
  color: #B22727;
  padding: 20px 0px 5px 0px;
`;