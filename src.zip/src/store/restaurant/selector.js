export const selectRestaurantLocation = (reduxState) =>
  reduxState.restaurant.location;
